from django.shortcuts import render

# Create your views here.
'''

ChoiceFiled
ModelChoiceFiled（ChoiceFiled） ---- select(单选)
MultiModelChoiceFiled （ModelChoiceFiled）----select(多选)



class Book(model.Model):
    title = models.CharField(max_length=32)
    price = models.IntegerField()
    publish=model.Foreignkey("Publish")
    authors=model.ManyToMany("Author")




from django.forms import ModelForm
class BookForm(ModelForm):
    class Meta:
        model=Book
        fields="__all__"
        
        
        
    
from django import forms
class BookForm(forms.Form):
    title=forms.CharField(max_length=32)
    price=forms.IntegerField()
    publish = forms.ModelChoiceFiled("Publish")
    authors = forms.ModelMultipleChoiceField("Author")
 
 
 
form=BookForm()


for i in form:
    if isinstance(i,ModelChoiceFiled):
        pass 
  
        
'''



