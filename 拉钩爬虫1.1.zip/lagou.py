# /usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2018/9/23 20:22 
# @Author : TrueNewBee
"""
2018-9-24 20:33:03

一个爬取 拉勾网成都应届毕业生 python 岗位的爬虫
并且保存了 excel文档而且很完美的保存!!!!!!!!!!
完美!
爬取了四页的数据!可以修改 pn 参数

这个是面向过程的  没有面向对象 这是1.0版本 可以进行迭代!!!!


2018-11-23 23:16:57
总结一下
拉钩 网 对爬虫进行了限制

1. 由于下面得数据 都是json请求,没做限制
2. 而后面的爬取网页详情的有限制,毕竟是 get请求

优化,增加get爬虫的睡眠时间,然后写入excel表格 就很完美啦

明天优化,睡觉觉!!!
2018-11-26 11:52:23
继续优化自己的代码 先用函数封装一下


"""
import requests
import json
import time
import xlwt
from bs4 import BeautifulSoup
import test

# 创建一个excel表
book = xlwt.Workbook()  # 创建excel文件
sheet = book.add_sheet('sheet1')  # 创建一个表
title = ['公司名字', '工作年限', '职位', '薪水', '工作类型','id','详细']
for i in range(len(title)):  # 存入第一行标题
    sheet.write(0, i, title[i])
row = 1  # 定义行


# 网站
url = 'https://www.lagou.com/jobs/positionAjax.json?city=%E6%88%90%E9%83%BD&needAddtionalResult=false&isSchoolJob=1'

headers = {
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Accept-Language': 'zh-CN,zh;q=0.9',
    'Connection': 'keep-alive',
    'Cookie': 'WEBTJ-ID=20180918181741-165ec2f83d743-0ee41db9c69e0e-6e1f147a-2073600-165ec2f83d95d1; _ga=GA1.2.1559975793.1537265862; user_trace_token=20180918181742-13d9fe9b-bb2c-11e8-baf2-5254005c3644; LGUID=20180918181742-13da0831-bb2c-11e8-baf2-5254005c3644; JSESSIONID=ABAAABAAAFCAAEG0FCA6542C1D06F1F470B0A7189B8AD06; index_location_city=%E6%88%90%E9%83%BD; TG-TRACK-CODE=index_search; _gid=GA1.2.1437892044.1537705170; LGSID=20180923201929-eb4f9cfb-bf2a-11e8-bb56-5254005c3644; PRE_UTM=; PRE_HOST=www.baidu.com; PRE_SITE=https%3A%2F%2Fwww.baidu.com%2Flink%3Furl%3DXpamso_IxFbfBezXbGYWv8-vI3sYyGf67_89jrtjXQK%26wd%3D%26eqid%3Da27f010200061c48000000025ba784cc; PRE_LAND=https%3A%2F%2Fwww.lagou.com%2F; Hm_lvt_4233e74dff0ae5bd0a3d81c6ccf756e6=1537265862,1537265872,1537354446,1537705170; LGRID=20180923201940-f1eea38b-bf2a-11e8-bb56-5254005c3644; Hm_lpvt_4233e74dff0ae5bd0a3d81c6ccf756e6=1537705181; SEARCH_ID=baf28c394763403c8afc3fc36dce76a4',
    'Host': 'www.lagou.com',
    'Origin': 'https://www.lagou.com',
    'Referer': 'https://www.lagou.com/jobs/list_python?isSchoolJob=1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36',
    'X-Anit-Forge-Code': '0',
    'X-Anit-Forge-Token': 'None',
    'X-Requested-With': 'XMLHttpRequest',
}
datas = []
positionId_List = []
for i in range(1, 5):
    data = {
        'first': 'true',
        'pn': i,
        'kd': 'python',
    }
    html = requests.post(url, data=data, headers=headers)
    jsonData = html.json()['content']['positionResult']['result']
    for item in jsonData:
        time.sleep(1)
        print('*'*80)
        print(item['companyFullName'])
        print(item['workYear'])
        print(item['positionName'])
        print(item['salary'])
        print(item['secondType'])
        print(item['secondType'])
        datas.append(item['companyFullName'])
        datas.append(item['workYear'])
        datas.append(item['positionName'])
        datas.append(item['salary'])
        datas.append(item['positionId'])
        # positionId_List.append(item['positionId'])
        detal = test.go(item['positionId'])
        datas.append(detal)
        for index in range(len(datas)):  # 依次写入每一行
            sheet.write(row, index, datas[index])
        datas.clear()
        row += 1
book.save('公司招聘.xls')



# 创建一个excel表
# book = xlwt.Workbook()  # 创建excel文件
# sheet = book.add_sheet('sheet1')  # 创建一个表
# title = ['公司ID', '岗位详细信息']
# for i in range(len(title)):  # 存入第一行标题
#     sheet.write(0, i, title[i])
# row = 1  # 定义行

# data2 = []
# for i in positionId_List:
#     time.sleep(0.5)
#     i= str(i)
#     data2.append(i)
#     urls ='https://www.lagou.com/jobs/'+i+'.html'
#     html = requests.get(urls, headers=headers).text
#     soup = BeautifulSoup(html,'html.parser')
#     dd =  soup.find(name='dd', attrs={'class': 'job_bt'})
#     job_bt = dd.get_text()
#     data2.append(job_bt)
#     for index in range(len(data2)):  # 依次写入每一行
#         sheet.write(row, index, datas[index])
#     datas.clear()
#     row += 1
# book.save('公司职位详细.xls')